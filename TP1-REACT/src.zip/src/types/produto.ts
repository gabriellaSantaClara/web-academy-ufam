export interface Produto {
  id: string;
  nome: string;
  preco: number;
  fotos: string[];
}
